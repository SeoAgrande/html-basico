#!/bin/bash

# Author: Alex Grande
# Date: Abril 2024

#Colours
greenColour="\e[0;32m\033[1m"
endColour="\033[0m\e[0m"
redColour="\e[0;31m\033[1m"
blueColour="\e[0;34m\033[1m"
yellowColour="\e[0;33m\033[1m"
purpleColour="\e[0;35m\033[1m"
turquoiseColour="\e[0;36m\033[1m"
grayColour="\e[0;37m\033[1m"

trap ctrl_c INT

# Salida al cortar la ejecucion del programa
function ctrl_c(){
	exit 0
}

# Menu principal
function menu(){
	tput civis;
	echo -e "\n${redColour}[!] Menu principal${endColour}"
    echo -e "\n${yellowColour}[!]${grayColour} Seleccione una opcion: ${endColour}"

    #  Seleccion de fases
    echo -e "\n\t${yellowColour}[!]${grayColour} [1] BUSCAR ERRORES ${endColour}"
    echo -e "\n\t${yellowColour}[!]${grayColour} [2] BUSCAR FUNCIONES ${endColour}"
	echo -e "\n\t${yellowColour}[!]${grayColour} [exit] SALIR${endColour}"
    read action
	if [ $action == "1" ]; then
    	findErrors
    elif [ $action == "2" ]; then
    	findFunctions 
	elif [ $action == "exit" ]; then
		exitProgram
    else
      	menu
    fi
}

function exitProgram(){
	echo -e "\n${redColour}[!] Saliendo...\n${endColour}"
	tput cnorm; exit 0
}

function findErrors(){
    # Preguntame que fichero quieres buscar
    echo -e "\n${yellowColour}[!]${grayColour} Introduce el fichero donde buscar errores: ${endColour}"
    read file

    # Que palabra quieres buscar
    echo -e "\n${yellowColour}[!]${grayColour} Introduce la palabra a buscar: ${endColour}"
    read word

    # Busca la palabra error en el fichero y exportala a un fichero llamado errors.txt y muestralos con un cat
    echo -e "\n${redColour}[!] Guardando errores...\n${endColour}"
    grep -i -w $word $file > errors.txt
    cat errors.txt | more
    menu
}

function findFunctions(){  
    # Busca la palabra funcio en todos los ficheros con extension .sh de un directorio y muestra los resultados en pantalla 
    echo -e "\n${redColour}[!] Buscando funciones...\n${endColour}"
    grep -i "funcio" *.sh
    # Muestrame el total de funciones encontradas
    echo -e "\n${yellowColour}[!]${grayColour} Total de funciones encontradas: ${endColour}"
    grep -i "funcio" *.sh | wc -l
    menu
}

menu